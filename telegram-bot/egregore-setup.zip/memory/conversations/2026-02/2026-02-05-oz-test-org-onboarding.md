# Test Org Onboarding Complete

**Date:** 2026-02-05
**By:** oz
**For:** cem, ali

## Summary

Built and tested the Egregore test org onboarding flow. Ready for external testers.

## What Was Done

### Infrastructure
- Created `egregore-core` and `egregore-memory` repos for test org
- Set up separate Neo4j Aura instance for test org isolation
- Bot now routes queries to correct Neo4j based on Telegram channel ID

### Onboarding Flow
1. User joins Telegram group → bot DMs them with ASCII art welcome
2. Bot asks for GitHub username
3. Bot adds them as collaborator to both repos
4. Bot sends setup zip file
5. User unzips, runs `claude`, says "set me up"
6. Claude Code installs dependencies (uv, gh), handles auth, clones memory, registers user

### Commands Added
- `/onboarding` — Explains how Egregore works
- `/ask` — Merged your PR! Context-aware questions, self-reflection, async to others

### Files Updated
- `CLAUDE.md` — Generic, no Curve Labs references, all commands documented
- `README.md` — Prompt guidance for trust/API key questions
- `.claude/settings.json` — Broad permissions to minimize prompts
- Bot — ASCII art welcome, `/onboard` command, `/debug` command, zip sending

## Known Issues

1. **Permission prompts** — Users still see "Trust this folder?" and occasionally MCP prompts on first run. Can't fully eliminate due to Claude Code security model.

2. **uv installation** — If user doesn't have `uv`, setup installs it but MCPs won't activate until Claude Code restart.

3. **API key conflict** — Users with `ANTHROPIC_API_KEY` in their environment see extra prompt. Added guidance to select "No".

## Next Steps

- [ ] Test with actual external users
- [ ] Monitor for issues in test org channel
- [ ] Consider adding more org-agnostic seed data to Neo4j

## Git Workflow Note

We've been pushing directly to main. Going forward, use branches:
```bash
git checkout -b feature/my-change
# make changes
git push -u origin feature/my-change
# merge via PR or locally
```

---

Cem — your `/ask` command is merged and added to test org. Nice feature!
