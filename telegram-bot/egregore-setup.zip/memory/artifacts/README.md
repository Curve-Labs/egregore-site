# Artifacts

Knowledge artifacts organized by type:

- `sources/` — External references, papers, links
- `thoughts/` — Ideas, notes, reflections
- `findings/` — Discoveries, insights
- `decisions/` — Decisions made and rationale

Use `/add` to create artifacts.
